import java.awt.Desktop.Action;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.apache.poi.hssf.usermodel.HSSFWorkbook; 
import org.apache.poi.ss.usermodel.Cell; 
import org.apache.poi.ss.usermodel.Row; 
import org.apache.poi.ss.usermodel.Sheet; 
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook; 

public class MiniProject{

public static WebDriver driver;
public static Properties properties;	
		// Function to Create and invoke the Driver for Chrome and Edge
		public static void createDriver(int a) throws IOException {
			if(a==1){
			  System.setProperty("webdriver.chrome.driver","C:\\Users\\Akshansh\\Downloads\\chromedriver_win32\\chromedriver.exe");
			      driver=new ChromeDriver();
			}
			else if(a==2)
			{
				System.setProperty("webdriver.edge.driver", "C:\\Users\\Akshansh\\Downloads\\edgedriver_win64\\msedgedriver.exe");
				driver = new EdgeDriver();
			}
			     driver.manage().window().maximize();
			     driver.get("https://www.flipkart.com/");
			     driver.manage().timeouts().pageLoadTimeout(5,TimeUnit.SECONDS);
		
			if(driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/button[1]")).isDisplayed())
			{
				driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/button[1]")).click();
			}
			if(properties == null)
			{
				properties=new Properties();
				FileInputStream file =new FileInputStream("C:\\Users\\Akshansh\\workspace\\FirstSaleniumProject\\src\\config.properties");
				properties.load(file);
			}
			
		}
		
		
		//Function to hover and go to the Home Appliance Menu
		public static void homeAppliance() {
			
			WebElement tva=driver.findElement(By.xpath("//span[contains(text(),'TVs & Appliances')]"));
			
			Actions hover=new Actions(driver);
			hover.moveToElement(tva).build().perform();
			
			WebDriverWait wait=new WebDriverWait(driver,10);
			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Small Home Appliances')]")));
		driver.findElement(By.xpath("//a[contains(text(),'Small Home Appliances')]")).click();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		}
		
		
		//Function to add the product to the Cart
		public static void addToCart(String xpathProductKey) throws InterruptedException, IOException{
			
			
			driver.findElement(By.xpath(properties.getProperty(xpathProductKey))).click();
			WebDriverWait wait=new WebDriverWait(driver,5);
			wait.until(ExpectedConditions.numberOfWindowsToBe(2));
			Set<String> windowHandels=driver.getWindowHandles();
			Iterator<String> i=windowHandels.iterator();
			String page1=i.next();
			String page2=i.next();
			driver.switchTo().window(page2);
			Thread.sleep(5000);
			WebDriverWait wait1=new WebDriverWait(driver,10);
			wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='ADD TO CART']"))).click();
			//Screenshot taking process
			File source = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileHandler.copy(source, new File("./ss/Step 2" +".png"));
			
			WebDriverWait wait2=new WebDriverWait(driver,10);
			wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Place Order')]")));
			
			driver.close();
			driver.switchTo().window(page1);
		}
		
		
		
		// Function to get the CART VALUE
		public static String getCartPrice()
		{
			String cartPrice;
			driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[5]/div[1]/div[1]/a[1]")).click();
			WebDriverWait wait=new WebDriverWait(driver,10);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Place Order')]")));
			cartPrice=driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[3]/div[1]/span[1]/div[1]/div[1]/span[1]")).getText();
			driver.navigate().back();
			return cartPrice;
		}
		
		
		
		//Function to QUIT DRIVER
		public static void quitDriver()
		{
			driver.quit();
		}
	
		
		// Main method
		public static void main(String[]args) throws InterruptedException, IOException{
	
		int x;
		Scanner sc=new Scanner(System.in);
		do{
		System.out.println("Enter the option number corresponding to the browser you want to use\n1.Chrome\n2.Edge");
		x=sc.nextInt();
		if(x==1||x==2)
		{
			break;
		}
		else
		{
			System.out.println("Enter either Chrome or Edge browser");
		}
		}while(x!=1||x!=2);
	     sc.close();
	     
	     
	  //Using Properties File
	   createDriver(x);
	   
	   homeAppliance();
	   
	   addToCart("Product1");
	
	   addToCart("Product2");
	   
	   System.out.println("Price when two products are added: " + getCartPrice());
	   
	   addToCart("Product3");
	 
	   System.out.println("Price when three products are added: " + getCartPrice());
	   
	   quitDriver();
	    
	    }
	 } 